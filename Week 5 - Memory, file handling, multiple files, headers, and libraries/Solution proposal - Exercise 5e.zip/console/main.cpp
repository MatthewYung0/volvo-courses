#include <iostream>
#include "main.h"

int main()
{
    std::cout << add(12,12) << "  " << multiply(12,12) << "  " << subtract(12,11);
    return 0;
}
